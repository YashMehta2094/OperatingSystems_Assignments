#!/usr/bin/env bash

# Check for the archive argument
if [ -z "$1" ]; then
    echo "Usage: $0 <archive_name.tar.gz>"
    exit 1
fi

# Extract the folder name from the archive name
folder_name=$(basename "$1" .tar.gz)

# Create the folder and extract the archive
mkdir -p "$folder_name" && tar -xzf "$1" -C "$folder_name" || { echo "Failed to extract $1"; exit 1; }

# Copy the "infiles" and "files" directories into "$folder_name"
cp -r infiles "$folder_name/"
cp -r files/* "$folder_name/"
cp specs "$folder_name/"

# Change to the folder and run make fifo && make lru
cd "$folder_name" && make fifo && make lru || { echo "Make failed"; exit 1; }

# Define output folder names
fifo_out_name="${folder_name}_outputs_fifo"
lru_out_name="${folder_name}_outputs_lru"

# Create output directories
mkdir -p "$fifo_out_name"
mkdir -p "$lru_out_name"

# Loop through specs and execute fifo for each line
i=1
while IFS=' ' read -r num1 num2 num3; do
    # Skip empty lines
    if [[ -n "$num1" && -n "$num2" && -n "$num3" ]]; then
        ./fifo -M "$num1" -V "$num2" -P "$num3" -i "./infiles/infile$i" -o "$fifo_out_name/out$i" || { echo "FIFO command failed for infile$i"; exit 1; }
        ((i++))
    fi
done < specs

# Copy outputs into fifo folder
cp outfile* "$fifo_out_name/"

# Remove fifo outputs
rm outfile*

# Reset the counter and loop through specs again for lru
i=1
while IFS=' ' read -r num1 num2 num3; do
    if [[ -n "$num1" && -n "$num2" && -n "$num3" ]]; then
        ./lru -M "$num1" -V "$num2" -P "$num3" -i "./infiles/infile$i" -o "$lru_out_name/out$i" || { echo "LRU command failed for infile$i"; exit 1; }
        ((i++))
    fi
done < specs

# Copy outputs into lru folder
cp outfile* "$lru_out_name/"

# Store the total number of test cases
N=$((i-1))

# Copy back the outputs into the parent dir
cp -r "$fifo_out_name" ..
cp -r "$lru_out_name" ..

# Return to the parent directory
cd ..

# Cleanup: remove the folders created during extraction
rm -rf "$folder_name"

lru_ref_folder="ref_outputs_lru"

echo "------------< LRU >>-------------"
# Loop to compare each outfile and out with the reference
for ((i=1; i<=N; i++)); do
    # Compare out$i, no filtering
    if diff -wb "$lru_ref_folder/out$i" "$lru_out_name/out$i" > /dev/null; then
        echo -e "\033[32mOutput $i match\033[0m"  # Green
    else
        echo -e "\033[31mOutput $i differ\033[0m"  # Red
    fi

    # Compare outfile$i, ignoring date lines
    if diff -wb <(grep -vE '^[A-Za-z]{3} [A-Za-z]{3} [0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} .*|^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$lru_ref_folder/outfile$i") <(grep -vE '^[A-Za-z]{3} [A-Za-z]{3} [0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} .*|^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$lru_out_name/outfile$i") > /dev/null; then
        echo -e "\033[32mOutfile $i match\033[0m"  # Green
    else
        echo -e "\033[31mOutfile $i differ\033[0m"  # Red
    fi
    echo "--------------------------------"
done

fifo_ref_folder="ref_outputs_fifo"

echo "------------< FIFO >>------------"
for ((i=1; i<=N; i++)); do
    # Compare out$i, no filtering
    if diff -wb "$fifo_ref_folder/out$i" "$fifo_out_name/out$i" > /dev/null; then
        echo -e "\033[32mOutput $i match\033[0m"  # Green
    else
        echo -e "\033[31mOutput $i differ\033[0m"  # Red
    fi

    # Compare outfile$i, ignoring date lines
    if diff -wb <(grep -vE '^[A-Za-z]{3} [A-Za-z]{3} [0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} .*|^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$fifo_ref_folder/outfile$i") <(grep -vE '^[A-Za-z]{3} [A-Za-z]{3} [0-9]{1,2} [0-9]{2}:[0-9]{2}:[0-9]{2} .*|^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$fifo_out_name/outfile$i") > /dev/null; then
        echo -e "\033[32mOutfile $i match\033[0m"  # Green
    else
        echo -e "\033[31mOutfile $i differ\033[0m"  # Red
    fi
    echo "--------------------------------"
done
